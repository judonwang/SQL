Our link was originally a SQL dump, but we converted it into CSVs to use for the assignment.
Because our link doesn't show any CSVs, we included them in the ZIP file.