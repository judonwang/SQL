import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QDialog, QApplication, QTableWidgetItem, QHeaderView
from DATA225utils import make_connection

class MovieDialog(QDialog):
    '''
    The Movie dialog
    '''
    
    def __init__(self):
        """
        Load the UI and initialize its components.
        """
        super().__init__()
        
        # Load the dialog components.
        self.ui = uic.loadUi('movies_dialog.ui')

        # date menu and query button event handlers.
        self.ui.date_menu.currentIndexChanged.connect(self._initialize_table)
        self.ui.query_button.clicked.connect(self._enter_movie_data)
        
        # Initialize the date menu and the movie table.
        self._initialize_date_menu()
        self._initialize_table()
        
    def show_dialog(self):
        """
        Show this dialog.
        """
        self.ui.show()
    
    def _initialize_date_menu(self):
        """
        Initialize the student menu with student names from the database.
        """
        conn = make_connection(config_file = 'movies.ini')
        cursor = conn.cursor()
        
        sql = """
            SELECT ReleaseDate FROM movie_metadata
            """
        
        cursor.execute(sql)
        rows = cursor.fetchall()
            
        cursor.close()
        conn.close()

        # Set the menu items to the release dates.
        for row in rows:
            name = row[0]
            self.ui.date_menu.addItem(str(name), row)  
            
    def _adjust_column_widths(self):
        """
        Adjust the column widths of the class table to fit the contents.
        """
        header = self.ui.movie_table.horizontalHeader();
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        
    def _initialize_table(self):
        """
        Clear the table and set the column headers.
        """
        self.ui.movie_table.clear()

        col = ['  Release Date  ', '   IMDB_ID   ', '  Original Title  ', '  Budget  ']
        self.ui.movie_table.setHorizontalHeaderLabels(col)        
        #self._adjust_column_widths()
        
    def _enter_movie_data(self):    
        """
        Enter class data from the query into 
        the student and takes tables.
        """    
        name = self.ui.date_menu.currentData()
        date = name[0]
        
        conn = make_connection(config_file = 'movies.ini')
        cursor = conn.cursor()

        sql = ( """
            SELECT ReleaseDate, IMDB_ID, Original_Title, budget
            FROM movie_metadata
            """
          f"WHERE ReleaseDate > '{date}' "
            """
            ORDER BY ReleaseDate
            """ 
              )    
        
        cursor.execute(sql)
        rows = cursor.fetchall()
              
        cursor.close()
        conn.close()
       
        # Set the movie data into the table cells.
        row_index = 0
        for row in rows:
            column_index = 0
            
            for data in row:
                item = QTableWidgetItem(str(data))
                self.ui.movie_table.setItem(row_index, column_index, item)
                column_index += 1

            row_index += 1
        self.ui.lcdNumber.display(len(rows))
        #self._adjust_column_widths()
        
if __name__ == '__main__':
    app = QApplication(sys.argv)
    form = MovieDialog()
    form.show_dialog()
    sys.exit(app.exec_())        