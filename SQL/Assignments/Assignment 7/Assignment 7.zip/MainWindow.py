from PyQt5 import uic
from PyQt5.QtWidgets import QDialog, QApplication, QTableWidgetItem, QHeaderView
import sys
from PyQt5.QtGui import QWindow
from MovieDialog import MovieDialog
from RatingsDialog import RatingsDialog

class MainWindow(QWindow):
    """
    The main application window.
    """
    
    def __init__(self):
        """
        Load the UI and initialize its components.
        """
        super().__init__()
        
        self.ui = uic.loadUi('gui_app.ui')
        self.ui.show();
        
        # Movie dialog.
        self._movie_dialog = MovieDialog()
        self.ui.movies_button.clicked.connect(self._show_movie_dialog)
        
        # Teacher students dialog.
        self._ratings_dialog = RatingsDialog()
        self.ui.users_button.clicked.connect(self._show_ratings_dialog)

    def _show_movie_dialog(self):
        """
        Show the movies dialog.
        """
        self._movie_dialog.show_dialog()

    def _show_ratings_dialog(self):
        """
        Show the ratings dialog.
        """
        self._ratings_dialog.show_dialog()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    form = MainWindow()
    form.ui.show()
    sys.exit(app.exec_())