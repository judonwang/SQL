import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QDialog, QApplication, QTableWidgetItem, QHeaderView
from DATA225utils import make_connection

class RatingsDialog(QDialog):
    """
    The ratings dialog.
    """
    
    def __init__(self):
        """
        Load the UI and initialize its components.
        """
        super().__init__()
        
        # Load the dialog components.
        self.ui = uic.loadUi('ratings_dialog.ui')

        # Teacher menu and query button event handlers.
        #self.ui.ratings_menu.currentIndexChanged.connect(self._initialize_table)
        self.ui.doubleSpinBox.valueChanged.connect(self._initialize_table)
        self.ui.query_button.clicked.connect(self._enter_user_data)
        
        # Initialize the teacher menu and the student table.
        self._initialize_ratings_menu()
        self._initialize_table()
        
    def show_dialog(self):
        """
        Show this dialog.
        """
        self.ui.show()
    
    def _initialize_ratings_menu(self):
        """
        Initialize the ratings menu with ratings from 1-10.
        Dont need anymore
        """
        #name = [x for x in range(1, 11)]
        #for num in name:
        #    self.ui.ratings_menu.addItem(str(num), num)
    def _adjust_column_widths(self):
        """
        Adjust the column widths of the user table to fit the contents.
        """
        header = self.ui.user_table.horizontalHeader();
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.Stretch)
        
    def _initialize_table(self):
        """
        Clear the table and set the column headers.
        """
        self.ui.user_table.clear()

        col = ['  ID  ', '   First   ', '   Last   ', 'User Name']
        self.ui.user_table.setHorizontalHeaderLabels(col)        
        self._adjust_column_widths()
        
    def _enter_user_data(self):    
        """
        Enter user data from the query into the user table.
        """    
      #  name = self.ui.ratings_menu.currentData()
        name = self.ui.doubleSpinBox.value()
        rating = name
        
        conn = make_connection(config_file = 'movies.ini')
        cursor = conn.cursor()
        sql = ( """
            SELECT DISTINCT u.User_ID, u.First_Name, u.Last_Name, u.User_Name
            FROM users u, movie_ratings m
            """
          f"WHERE m.ratings > '{rating}' "
            """
            AND u.User_ID = m.User_ID
            """ 
              )    
        
        cursor.execute(sql)
        rows = cursor.fetchall()
              
        cursor.close()
        conn.close()
       
        # Set the user data into the table cells.
        row_index = 0
        for row in rows:
            column_index = 0
            
            for data in row:
                item = QTableWidgetItem(str(data))
                self.ui.user_table.setItem(row_index, column_index, item)
                column_index += 1

            row_index += 1
        
if __name__ == '__main__':
    app = QApplication(sys.argv)
    form = RatingsDialog()
    form.show_dialog()
    sys.exit(app.exec_())